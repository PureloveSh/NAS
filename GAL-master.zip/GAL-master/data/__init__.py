from .cifar10 import Data as cifar10
